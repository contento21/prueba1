package pe.edu.upc.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MascotitasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MascotitasApplication.class, args);
	}
	
}
